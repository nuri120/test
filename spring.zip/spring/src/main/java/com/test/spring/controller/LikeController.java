package com.test.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.ServletContext;

import java.sql.*;

@Controller
public class LikeController {

    private final String URL = "jdbc:mysql://localhost:3306/myDB";
    private final String USER = "root";
    private final String PASSWORD = "1234";

    @Autowired
    private ServletContext servletContext;

    @PostMapping("/addLike")
    public String addLike(Model model, @SessionAttribute("userId") String userId, @RequestParam("postId") int postId) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO likes (memberId, postId) VALUES (?, ?)")) {
            pstmt.setString(1, userId);
            pstmt.setInt(2, postId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "redirect:/board";
    }

    @PostMapping("/deleteLike")
    public String deleteLike(Model model, @SessionAttribute("userId") String userId, @RequestParam("postId") int postId) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM likes WHERE memberId = ? AND postId = ?")) {
            pstmt.setString(1, userId);
            pstmt.setInt(2, postId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "redirect:/board";
    }
}