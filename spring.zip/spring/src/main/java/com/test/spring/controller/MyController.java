package com.test.spring.controller;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.test.spring.model.Member;

import jakarta.servlet.http.HttpSession;

import java.sql.Connection;
import javax.sql.DataSource;

@Controller
public class MyController {
    private final DataSource dataSource;

    public MyController(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    
    // 초기 화면인 initial.jsp 뷰를 보여줌
    @GetMapping("/initial")
    public String loginForm() {
        return "initial";
    }

    // 요청 처리
    @PostMapping("/login")
    public String login(@RequestParam("id") String id, @RequestParam("passwd") String password, Model model, HttpSession session) {
        ResultSet rs = null;

        try (Connection conn = dataSource.getConnection()) {
            String sql = "select id, passwd from member where id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, id);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    String rId = rs.getString("id");
                    String rPasswd = rs.getString("passwd");
                    if (id.equals(rId) && password.equals(rPasswd)) {
                        // 메인으로
                        session.setAttribute("userId", id); // 세션에 사용자 정보 저장
                        return "main"; // 로그인 성공 시 메인 페이지로 리다이렉트
                    }
                    else {
                        // 비밀번호 불일치
                        model.addAttribute("message", "비밀번호가 일치하지 않습니다.");
                        return "initial";
                    }
                }
                else {
                    // 아이디 불일치
                    model.addAttribute("message", "아이디가 일치하지 않습니다.");
                    return "initial";
                }
            }

        } catch (SQLException ex) {
            model.addAttribute("message", "테이블 호출이 실패했습니다.<br>SQLException: " + ex.getMessage());
            return "initial";
        }
    }

    // 회원가입 뷰
    @GetMapping("/insert")
    public String showForm() {
        return "insert"; //insert.jsp의 이름
    }

    // 비밀번호 변경 뷰
    @GetMapping("/update")
    public String changeForm() {
        return "update"; 
    }

    // 메인 화면
    @GetMapping("/main")
    public String showMain() {
        return "main"; 
    }

    @PostMapping("/insert01_process")
    public String insert01_process(Member member, Model model) {
        try (Connection conn = dataSource.getConnection()) {
            String sql = "INSERT INTO Member(id, passwd, name) VALUES(?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, member.getId());
                stmt.setString(2, member.getPasswd());
                stmt.setString(3, member.getName());
                stmt.executeUpdate();
            }
        model.addAttribute("message", "회원가입이 완료되었습니다.");
        } catch (SQLException ex) {
            model.addAttribute("message", "회원가입을 실패했습니다.<br>SQLException: " + ex.getMessage());
        }
        return "initial"; // 로그인 화면으로 이동
    }

    @PostMapping("/update01_process")
    public String update01_process(Member member, Model model) {
        ResultSet rs = null;
        try (Connection conn = dataSource.getConnection()) {
            String sql = "select id, name from member where id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, member.getId());
                rs = stmt.executeQuery();

                if (rs.next()) {
                    String rId = rs.getString("id");
                    String rName = rs.getString("name");
                    if (member.getId().equals(rId) && member.getName().equals(rName)) {
                        sql = "update member set passwd = ? where id = ?";
                        PreparedStatement stmt2 = conn.prepareStatement(sql);
                        // 인자를 2개 이상 줘야됨
                        stmt2.setString(1, member.getPasswd());
                        stmt2.setString(2, member.getId());
                        stmt2.executeUpdate();
                        model.addAttribute("message", "회원가입이 완료되었습니다.");
                    } else
                        model.addAttribute("message", "이름이 일치하지 않습니다.");
                } else
                     model.addAttribute("message", "아이디가 일치하지 않습니다.");
                }
            } catch (SQLException ex) {
                model.addAttribute("message", "회원가입을 실패했습니다.<br>SQLException: " + ex.getMessage());
        }
        return "initial"; // 로그인 화면으로 이동
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, Model model) {
        // 세션 무효화
        session.invalidate();
        
        // 로그아웃 메시지 추가
        model.addAttribute("message", "로그아웃 되었습니다.");
        
        return "initial";
    }
}
