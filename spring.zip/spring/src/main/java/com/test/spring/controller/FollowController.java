package com.test.spring.controller;

import java.sql.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import jakarta.servlet.ServletContext;

@Controller
public class FollowController {
    
    private final String URL = "jdbc:mysql://localhost:3306/myDB";
    private final String USER = "root";
    private final String PASSWORD = "1234";

    @Autowired
    private ServletContext servletContext;

    @GetMapping("/following")
    public String showFollowing() {
        return "following";
    }

    @PostMapping("/addFollow")
    public String addFollow(Model model, @SessionAttribute("userId") String userId, @RequestParam("followeeId") String followeeId) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO following (followerId, followeeId) VALUES (?, ?)")) {
            pstmt.setString(1, userId);
            pstmt.setString(2, followeeId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        model.addAttribute("message", "팔로우가 완료되었습니다.");
        return "following";
    }

    @PostMapping("/deleteFollow")
    public String deleteLike(Model model, @SessionAttribute("userId") String userId, @RequestParam("followeeId") String followeeId) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM following WHERE followerId = ? AND followeeId = ?")) {
            pstmt.setString(1, userId);
            pstmt.setString(2, followeeId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        model.addAttribute("message", "팔로우를 해제했습니다.");
        return "following";
    }

}
