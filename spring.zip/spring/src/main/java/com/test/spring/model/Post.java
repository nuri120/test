package com.test.spring.model;

public class Post {
    private int id; // 파일의 고유번호
    private String title;
    private String content;
    private String fileName;
    private String memberId; // 작성자

    public Post() {

    }

    public Post(int id, String title, String content, String fileName, String memberId) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.fileName = fileName;
        this.memberId = memberId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
}
