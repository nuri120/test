package com.test.spring.model;

public class Following {
    private String follower;
    private String followee;

    public Following() {

    }
    public Following (String follower, String followee) {
        this.follower = follower;
        this.followee = followee;
    }
    public String getFollower() {
        return follower;
    }
    public void setFollower(String follower) {
        this.follower = follower;
    }
    public String getFollowee() {
        return followee;
    }
    public void setFollowee(String followee) {
        this.followee = followee;
    }
}

