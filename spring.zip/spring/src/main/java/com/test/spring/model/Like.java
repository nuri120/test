package com.test.spring.model;

public class Like {
    private int id; // 기본키
    private String memberId; // 좋아요를 누른 회원의 ID
    private int postId; // 좋아요가 눌린 게시물의 ID

    public Like() {
    }
    public Like(int id, String memberId, int postId) {
        this.id = id;
        this.memberId = memberId;
        this.postId = postId;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getMemberId() {
        return memberId;
    }
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public int getPostId() {
        return postId;
    }
    public void setPostId(int postId) {
        this.postId = postId;
    }
}
