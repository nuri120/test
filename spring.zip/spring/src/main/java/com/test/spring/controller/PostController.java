package com.test.spring.controller;

import com.test.spring.model.Post;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletContext;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


@Controller
public class PostController {

    private final String URL = "jdbc:mysql://localhost:3306/myDB";
    private final String USER = "root";
    private final String PASSWORD = "1234";

    @Autowired
    private ServletContext servletContext;

    @GetMapping("/board")
    public String board(Model model, @SessionAttribute("userId") String userId) {
        List<Post> posts = new ArrayList<>();
       
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
         PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM posts WHERE memberId = ?");
         ) {
            pstmt.setString(1, userId);
        
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Post post = new Post(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("file_name"), userId);
                    posts.add(post);
                }
        }
        
    } catch (SQLException e) {
            e.printStackTrace();
        }
        model.addAttribute("posts", posts);
        model.addAttribute("userId", userId);
        return "board";
    }

    @GetMapping("/writePost")
    public String writePostForm() {
        return "writePost"; // writePost.jsp 뷰로 연결
    }     

    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam("title") String title, @RequestParam("content") String content, @RequestParam("file") MultipartFile file,
    @SessionAttribute("userId") String userId) {
        String fileName = "";

        if (!file.isEmpty()) {
            fileName = file.getOriginalFilename();
        }
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO posts (title, content, file_name, memberId) VALUES (?, ?, ?, ?)")) {
            pstmt.setString(1, title);
            pstmt.setString(2, content);
            pstmt.setString(3, fileName);
            pstmt.setString(4, userId);
            pstmt.executeUpdate();
            
            // 파일 업로드 처리 코드
            if (!file.isEmpty()) {
                String uploadDir = servletContext.getRealPath("/") + "uploads";
                File uploadDirFile = new File(uploadDir);
                if (!uploadDirFile.exists()) {
                    uploadDirFile.mkdirs();
                }
                file.transferTo(new File(uploadDirFile, fileName));
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
        return "redirect:/board";
    }

    @GetMapping("/editPost")
    public String editPost(@RequestParam("id") int id, Model model, @SessionAttribute("userId") String userId) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM posts WHERE id = ?")) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Post post = new Post(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("file_name"), userId);
                    model.addAttribute("post", post);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "editPost";
    }

    @PostMapping("/updatePost")
    public String updatePost(@RequestParam("id") int id, @RequestParam("title") String title, @RequestParam("content") String content,
                             @RequestParam("newFile") MultipartFile newFile) {
        String fileName = newFile.getOriginalFilename();
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            if (newFile.getSize() > 0) {
                String uploadPath = servletContext.getRealPath("/") + "uploads";
                // 기존 파일 삭제
                try (PreparedStatement pstmt = conn.prepareStatement("SELECT file_name FROM posts WHERE id = ?")) {
                    pstmt.setInt(1, id);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            String oldFileName = rs.getString("file_name");
                            File oldFile = new File(uploadPath, oldFileName);
                            oldFile.delete();
                        }
                    }
                }
                // 새 파일 업로드
                newFile.transferTo(new File(uploadPath, fileName));
            } else {
                // 새 파일이 업로드되지 않은 경우 기존 파일 유지
                try (PreparedStatement pstmt = conn.prepareStatement("SELECT file_name FROM posts WHERE id = ?")) {
                    pstmt.setInt(1, id);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        if (rs.next()) {
                            fileName = rs.getString("file_name");
                        }
                    }
                }
            }

            try (PreparedStatement pstmt = conn.prepareStatement("UPDATE posts SET title = ?, content = ?, file_name = ? WHERE id = ?")) {
                pstmt.setString(1, title);
                pstmt.setString(2, content);
                pstmt.setString(3, fileName);
                pstmt.setInt(4, id);
                pstmt.executeUpdate();
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
        return "redirect:/board";
    }

    @GetMapping("/deletePost")
    public String deletePost(@RequestParam("id") int id) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM posts WHERE id = ?")) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "redirect:/board";
    }

    @GetMapping("/downloadFile")
    public void downloadFile(@RequestParam("id") int id, HttpServletResponse response) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement("SELECT file_name FROM posts WHERE id = ?")) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String fileName = rs.getString("file_name");
                    String uploadPath = servletContext.getRealPath("/") + "uploads";
                    File file = new File(uploadPath, fileName);
                    if (file.exists()) {
                        // 다운로드할 파일 이름 설정
                        response.setContentType("application/octet-stream");
                        response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
                        // 파일 내용을 response 스트림으로 전송
                        try (InputStream inStream = new FileInputStream(file); OutputStream outStream = response.getOutputStream()) {
                            byte[] buffer = new byte[4096];
                            int bytesRead;
                            while ((bytesRead = inStream.read(buffer)) != -1) {
                                outStream.write(buffer, 0, bytesRead);
                            }
                        }
                    }
                }
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    @GetMapping("/followingBoard")
public String followingBoard(Model model, @SessionAttribute("userId") String followerId) {
    List<Post> posts = new ArrayList<>();
   
    try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
         PreparedStatement pstmt = conn.prepareStatement("SELECT followeeId FROM following WHERE followerId = ?");
    ) {
        pstmt.setString(1, followerId);
        ResultSet rs = pstmt.executeQuery();
        
        while (rs.next()) {
            String followeeId = rs.getString("followeeId");

            try (PreparedStatement pstmtPosts = conn.prepareStatement("SELECT * FROM posts WHERE memberId = ?")) {
                pstmtPosts.setString(1, followeeId);
                ResultSet rsPosts = pstmtPosts.executeQuery();

                while (rsPosts.next()) {
                    Post post = new Post(
                        rsPosts.getInt("id"), rsPosts.getString("title"),
                        rsPosts.getString("content"), rsPosts.getString("file_name"),
                        followeeId);
                    posts.add(post);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    model.addAttribute("posts", posts);
    return "followingBoard";
}

}
